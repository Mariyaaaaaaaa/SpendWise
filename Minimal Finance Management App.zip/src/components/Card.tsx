import type { ReactNode, CSSProperties } from 'react'

interface CardProps {
  children: ReactNode
  style?: CSSProperties
  className?: string
}

export function Card({ children, style }: CardProps) {
  return (
    <div style={{
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: '20px 24px',
      ...style,
    }}>
      {children}
    </div>
  )
}

export function StatCard({
  label, value, change, positive, mono = true,
}: {
  label: string
  value: string
  change?: string
  positive?: boolean
  mono?: boolean
}) {
  return (
    <Card>
      <div style={{ color: 'var(--color-muted)', fontSize: 12, fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>
        {label}
      </div>
      <div style={{
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-display)',
        fontSize: 26, fontWeight: 500,
        color: 'var(--color-text)',
        letterSpacing: '-0.5px',
        marginBottom: 6,
      }}>
        {value}
      </div>
      {change && (
        <div style={{
          fontSize: 12, fontWeight: 500,
          color: positive ? 'var(--color-accent)' : 'var(--color-danger)',
        }}>
          {positive ? '↑' : '↓'} {change}
        </div>
      )}
    </Card>
  )
}
