import { useState, useMemo } from 'react'
import { Card } from '../components/Card'

interface Transaction {
  id: number
  merchant: string
  category: string
  date: string
  amount: number
  account: string
  icon: string
  type: 'debit' | 'credit'
}

const allTx: Transaction[] = [
  { id: 1, merchant: 'Whole Foods Market', category: 'Groceries', date: 'Jul 27', amount: -84.32, account: 'Chase ···4821', icon: '🛒', type: 'debit' },
  { id: 2, merchant: 'Venmo Transfer', category: 'Transfer', date: 'Jul 26', amount: -200.00, account: 'Chase ···4821', icon: '💸', type: 'debit' },
  { id: 3, merchant: 'Salary Deposit', category: 'Income', date: 'Jul 25', amount: 5200.00, account: 'Chase ···4821', icon: '💼', type: 'credit' },
  { id: 4, merchant: 'Netflix', category: 'Entertainment', date: 'Jul 24', amount: -15.99, account: 'Amex ···2291', icon: '🎬', type: 'debit' },
  { id: 5, merchant: 'Shell Gas Station', category: 'Transport', date: 'Jul 23', amount: -54.10, account: 'Chase ···4821', icon: '⛽', type: 'debit' },
  { id: 6, merchant: 'Rent — August', category: 'Housing', date: 'Jul 22', amount: -1400.00, account: 'Chase ···4821', icon: '🏠', type: 'debit' },
  { id: 7, merchant: 'Amazon.com', category: 'Shopping', date: 'Jul 22', amount: -128.45, account: 'Amex ···2291', icon: '📦', type: 'debit' },
  { id: 8, merchant: 'Starbucks', category: 'Food & Drink', date: 'Jul 21', amount: -6.75, account: 'Amex ···2291', icon: '☕', type: 'debit' },
  { id: 9, merchant: 'Spotify Premium', category: 'Entertainment', date: 'Jul 20', amount: -9.99, account: 'Amex ···2291', icon: '🎵', type: 'debit' },
  { id: 10, merchant: 'AAPL Stock Purchase', category: 'Investment', date: 'Jul 18', amount: -1250.00, account: 'Fidelity ···5567', icon: '📈', type: 'debit' },
  { id: 11, merchant: 'Uber', category: 'Transport', date: 'Jul 17', amount: -18.40, account: 'Chase ···4821', icon: '🚗', type: 'debit' },
  { id: 12, merchant: 'Chipotle', category: 'Food & Drink', date: 'Jul 16', amount: -14.25, account: 'Amex ···2291', icon: '🌯', type: 'debit' },
  { id: 13, merchant: 'VTI Dividend', category: 'Investment', date: 'Jul 10', amount: 42.80, account: 'Fidelity ···5567', icon: '💰', type: 'credit' },
  { id: 14, merchant: 'Freelance Payment', category: 'Income', date: 'Jul 8', amount: 800.00, account: 'Chase ···4821', icon: '🖥️', type: 'credit' },
  { id: 15, merchant: 'Ally Interest', category: 'Income', date: 'Jul 1', amount: 38.44, account: 'Ally ···9034', icon: '🏦', type: 'credit' },
]

const categories = ['All', 'Groceries', 'Income', 'Entertainment', 'Transport', 'Housing', 'Shopping', 'Food & Drink', 'Investment', 'Transfer']

export default function Transactions() {
  const [search, setSearch] = useState('')
  const [cat, setCat] = useState('All')
  const [sort, setSort] = useState<'date' | 'amount'>('date')

  const filtered = useMemo(() => {
    let list = [...allTx]
    if (cat !== 'All') list = list.filter(t => t.category === cat)
    if (search) list = list.filter(t =>
      t.merchant.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase())
    )
    if (sort === 'amount') list.sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount))
    return list
  }, [search, cat, sort])

  const totalIn = filtered.filter(t => t.amount > 0).reduce((s, t) => s + t.amount, 0)
  const totalOut = filtered.filter(t => t.amount < 0).reduce((s, t) => s + t.amount, 0)

  return (
    <div style={{ padding: '28px 32px', paddingBottom: 40 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.4px' }}>
          Transactions
        </h1>
        <p style={{ color: 'var(--color-muted)', fontSize: 13, margin: '4px 0 0' }}>
          {filtered.length} transactions · In: <span style={{ color: 'var(--color-accent)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>${totalIn.toFixed(2)}</span>
          {' '}· Out: <span style={{ color: 'var(--color-danger)', fontFamily: 'var(--font-mono)', fontSize: 12 }}>${Math.abs(totalOut).toFixed(2)}</span>
        </p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
        {/* Search */}
        <div style={{ position: 'relative', flex: '1', minWidth: 200 }}>
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--color-muted)', fontSize: 13 }}>
            🔍
          </span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search transactions..."
            style={{
              width: '100%', padding: '8px 12px 8px 34px',
              border: '1px solid var(--color-border)', borderRadius: 8,
              fontSize: 13, fontFamily: 'var(--font-body)',
              background: 'var(--color-surface)', color: 'var(--color-text)',
              outline: 'none',
            }}
          />
        </div>

        {/* Sort */}
        <select
          value={sort}
          onChange={e => setSort(e.target.value as 'date' | 'amount')}
          style={{
            padding: '8px 12px', border: '1px solid var(--color-border)', borderRadius: 8,
            fontSize: 13, fontFamily: 'var(--font-body)',
            background: 'var(--color-surface)', color: 'var(--color-text)',
            cursor: 'pointer', outline: 'none',
          }}
        >
          <option value="date">Sort: Date</option>
          <option value="amount">Sort: Amount</option>
        </select>
      </div>

      {/* Category chips */}
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 20 }}>
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            padding: '5px 12px', borderRadius: 99, fontSize: 12, fontWeight: 500,
            border: `1px solid ${cat === c ? 'var(--color-text)' : 'var(--color-border)'}`,
            background: cat === c ? 'var(--color-text)' : 'var(--color-surface)',
            color: cat === c ? '#fff' : 'var(--color-muted)',
            cursor: 'pointer', fontFamily: 'var(--font-body)',
            transition: 'all 0.12s',
          }}>{c}</button>
        ))}
      </div>

      {/* Transaction list */}
      <Card style={{ padding: 0 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--color-muted)', fontSize: 13 }}>
            No transactions match your filters
          </div>
        ) : filtered.map((tx, i) => (
          <div key={tx.id} style={{
            display: 'flex', alignItems: 'center', padding: '13px 24px',
            borderBottom: i < filtered.length - 1 ? '1px solid var(--color-border)' : 'none',
            transition: 'background 0.1s',
          }}
            onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.background = 'var(--color-bg)'}
            onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.background = 'transparent'}
          >
            <div style={{
              width: 36, height: 36, borderRadius: 10, flexShrink: 0,
              background: 'var(--color-bg)', border: '1px solid var(--color-border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 15, marginRight: 12,
            }}>{tx.icon}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {tx.merchant}
              </div>
              <div style={{ fontSize: 11, color: 'var(--color-muted)', marginTop: 1 }}>
                {tx.category} · {tx.account} · {tx.date}
              </div>
            </div>
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 500, flexShrink: 0, marginLeft: 16,
              color: tx.amount > 0 ? 'var(--color-accent)' : 'var(--color-text)',
            }}>
              {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
            </div>
          </div>
        ))}
      </Card>
    </div>
  )
}
