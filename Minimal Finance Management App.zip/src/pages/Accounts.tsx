import { useState } from 'react'
import { Card } from '../components/Card'

const accounts = [
  {
    id: 1, type: 'checking', bank: 'Chase Bank', name: 'Primary Checking',
    last4: '4821', balance: 8420.55, color: '#111318',
  },
  {
    id: 2, type: 'savings', bank: 'Ally Bank', name: 'High-Yield Savings',
    last4: '9034', balance: 14610.75, color: '#16a34a',
  },
  {
    id: 3, type: 'credit', bank: 'American Express', name: 'Platinum Card',
    last4: '2291', balance: -1800.20, color: '#1d4ed8',
  },
  {
    id: 4, type: 'investment', bank: 'Fidelity', name: 'Brokerage Account',
    last4: '5567', balance: 32480.00, color: '#d97706',
  },
]

const typeLabel: Record<string, string> = {
  checking: 'Checking', savings: 'Savings', credit: 'Credit Card', investment: 'Investment',
}

const txByAccount: Record<number, { id: number; desc: string; date: string; amount: number }[]> = {
  1: [
    { id: 1, desc: 'Whole Foods Market', date: 'Jul 27', amount: -84.32 },
    { id: 2, desc: 'Venmo Transfer', date: 'Jul 26', amount: -200.00 },
    { id: 3, desc: 'Direct Deposit', date: 'Jul 25', amount: 5200.00 },
  ],
  2: [
    { id: 4, desc: 'Interest Credit', date: 'Jul 01', amount: 38.44 },
    { id: 5, desc: 'Transfer from Checking', date: 'Jun 30', amount: 500.00 },
  ],
  3: [
    { id: 6, desc: 'Netflix', date: 'Jul 24', amount: -15.99 },
    { id: 7, desc: 'Amazon.com', date: 'Jul 22', amount: -128.45 },
    { id: 8, desc: 'Payment Received', date: 'Jul 20', amount: 500.00 },
  ],
  4: [
    { id: 9, desc: 'AAPL Purchase', date: 'Jul 18', amount: -1250.00 },
    { id: 10, desc: 'Dividend — VTI', date: 'Jul 10', amount: 42.80 },
  ],
}

export default function Accounts() {
  const [selected, setSelected] = useState<number | null>(null)

  const totalNet = accounts.reduce((s, a) => s + a.balance, 0)

  return (
    <div style={{ padding: '28px 32px', paddingBottom: 40 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.4px' }}>
          Accounts & Wallets
        </h1>
        <p style={{ color: 'var(--color-muted)', fontSize: 13, margin: '4px 0 0' }}>
          Net worth: <strong style={{ fontFamily: 'var(--font-mono)', color: 'var(--color-text)' }}>
            ${totalNet.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </strong>
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        {accounts.map(acc => (
          <div
            key={acc.id}
            onClick={() => setSelected(selected === acc.id ? null : acc.id)}
            style={{
              background: selected === acc.id ? acc.color : 'var(--color-surface)',
              border: `1px solid ${selected === acc.id ? 'transparent' : 'var(--color-border)'}`,
              borderRadius: 'var(--radius-lg)',
              padding: '20px 24px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
            }}
          >
            {/* Card top */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <div style={{
                  fontSize: 11, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase',
                  color: selected === acc.id ? 'rgba(255,255,255,0.65)' : 'var(--color-muted)',
                  marginBottom: 4,
                }}>
                  {typeLabel[acc.type]}
                </div>
                <div style={{
                  fontSize: 15, fontWeight: 600,
                  color: selected === acc.id ? '#fff' : 'var(--color-text)',
                }}>
                  {acc.name}
                </div>
              </div>
              <div style={{
                fontSize: 11, padding: '4px 10px', borderRadius: 99,
                background: selected === acc.id ? 'rgba(255,255,255,0.15)' : 'var(--color-bg)',
                color: selected === acc.id ? 'rgba(255,255,255,0.85)' : 'var(--color-muted)',
                fontWeight: 500,
              }}>
                {acc.bank}
              </div>
            </div>

            {/* Balance */}
            <div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 24, fontWeight: 500,
                letterSpacing: '-0.5px',
                color: selected === acc.id
                  ? '#fff'
                  : acc.balance < 0 ? 'var(--color-danger)' : 'var(--color-text)',
              }}>
                {acc.balance < 0 ? '-' : ''}${Math.abs(acc.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <div style={{
                fontSize: 12, marginTop: 4,
                color: selected === acc.id ? 'rgba(255,255,255,0.55)' : 'var(--color-muted)',
              }}>
                ···· {acc.last4}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Transaction detail */}
      {selected && (
        <Card style={{ padding: 0 }}>
          <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--color-border)' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 600, margin: 0 }}>
              Recent Activity — {accounts.find(a => a.id === selected)?.name}
            </h3>
          </div>
          {(txByAccount[selected] ?? []).map((tx, i, arr) => (
            <div key={tx.id} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '13px 24px',
              borderBottom: i < arr.length - 1 ? '1px solid var(--color-border)' : 'none',
            }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{tx.desc}</div>
                <div style={{ fontSize: 11, color: 'var(--color-muted)', marginTop: 1 }}>{tx.date}</div>
              </div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 500,
                color: tx.amount > 0 ? 'var(--color-accent)' : 'var(--color-text)',
              }}>
                {tx.amount > 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  )
}
