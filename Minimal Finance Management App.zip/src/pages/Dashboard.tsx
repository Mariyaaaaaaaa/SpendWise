import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts'
import { Card, StatCard } from '../components/Card'
import type { CSSProperties } from 'react'

type Page = 'dashboard' | 'accounts' | 'analytics' | 'goals' | 'transactions' | 'settings'

const cashflow = [
  { month: 'Feb', income: 5200, expenses: 3100 },
  { month: 'Mar', income: 5400, expenses: 3400 },
  { month: 'Apr', income: 5100, expenses: 2900 },
  { month: 'May', income: 5800, expenses: 3200 },
  { month: 'Jun', income: 5600, expenses: 3600 },
  { month: 'Jul', income: 6100, expenses: 3100 },
]

const categoryData = [
  { name: 'Housing', value: 1400, color: '#111318' },
  { name: 'Food', value: 580, color: '#16a34a' },
  { name: 'Transport', value: 320, color: '#6b7280' },
  { name: 'Entertainment', value: 210, color: '#d97706' },
  { name: 'Other', value: 590, color: '#e8eaed' },
]

const recentTx = [
  { id: 1, merchant: 'Whole Foods Market', category: 'Groceries', date: 'Jul 27', amount: -84.32, icon: '🛒' },
  { id: 2, merchant: 'Salary Deposit', category: 'Income', date: 'Jul 25', amount: 5200.00, icon: '💼' },
  { id: 3, merchant: 'Netflix', category: 'Entertainment', date: 'Jul 24', amount: -15.99, icon: '🎬' },
  { id: 4, merchant: 'Shell Gas Station', category: 'Transport', date: 'Jul 23', amount: -54.10, icon: '⛽' },
  { id: 5, merchant: 'Rent — August', category: 'Housing', date: 'Jul 22', amount: -1400.00, icon: '🏠' },
]

const headerStyle: CSSProperties = {
  padding: '28px 32px 0',
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  marginBottom: 24,
}

const gridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, 1fr)',
  gap: 16,
  padding: '0 32px',
  marginBottom: 24,
}

export default function Dashboard({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const totalBalance = '$24,831.50'

  return (
    <div style={{ minHeight: '100vh', paddingBottom: 32 }}>
      {/* Header */}
      <div style={headerStyle}>
        <div>
          <div style={{ color: 'var(--color-muted)', fontSize: 13, marginBottom: 4 }}>
            Monday, July 28
          </div>
          <h1 style={{
            fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700,
            color: 'var(--color-text)', margin: 0, letterSpacing: '-0.4px',
          }}>
            Good morning, Jamie 👋
          </h1>
        </div>
        <button style={{
          background: 'var(--color-accent)', color: '#fff',
          border: 'none', borderRadius: 8,
          padding: '8px 16px', fontSize: 13, fontWeight: 600,
          cursor: 'pointer', fontFamily: 'var(--font-body)',
        }}>
          + Add Transaction
        </button>
      </div>

      {/* Stats row */}
      <div style={gridStyle}>
        <StatCard label="Total Balance" value={totalBalance} change="3.2% this month" positive />
        <StatCard label="Monthly Income" value="$6,100" change="8.5% vs last month" positive />
        <StatCard label="Monthly Spend" value="$3,100" change="1.4% vs last month" positive={false} />
        <StatCard label="Savings Rate" value="49%" change="up from 42%" positive />
      </div>

      {/* Charts row */}
      <div style={{ padding: '0 32px', display: 'grid', gridTemplateColumns: '1fr 300px', gap: 16, marginBottom: 24 }}>
        {/* Cashflow */}
        <Card>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: 0 }}>Cashflow</h2>
              <p style={{ color: 'var(--color-muted)', fontSize: 12, margin: '2px 0 0' }}>Income vs Expenses — last 6 months</p>
            </div>
            <div style={{ display: 'flex', gap: 16, fontSize: 12 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--color-muted)' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--color-accent)', display: 'inline-block' }} />
                Income
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--color-muted)' }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#e8eaed', border: '1px solid #d1d5db', display: 'inline-block' }} />
                Expenses
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={cashflow}>
              <defs>
                <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#16a34a" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6b7280" stopOpacity={0.12} />
                  <stop offset="95%" stopColor="#6b7280" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ border: '1px solid var(--color-border)', borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => [`$${v.toLocaleString()}`, '']}
              />
              <Area type="monotone" dataKey="income" stroke="#16a34a" strokeWidth={2} fill="url(#incomeGrad)" />
              <Area type="monotone" dataKey="expenses" stroke="#9ca3af" strokeWidth={2} fill="url(#expGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Spending breakdown */}
        <Card>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 4px' }}>Spending</h2>
          <p style={{ color: 'var(--color-muted)', fontSize: 12, margin: '0 0 16px' }}>July 2026</p>
          <PieChart width={120} height={120} style={{ margin: '0 auto 16px' }}>
            <Pie data={categoryData} cx={56} cy={56} innerRadius={36} outerRadius={56} dataKey="value" strokeWidth={0}>
              {categoryData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
            </Pie>
          </PieChart>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {categoryData.map(c => (
              <div key={c.name} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: c.color, display: 'inline-block', border: c.color === '#e8eaed' ? '1px solid #d1d5db' : 'none' }} />
                  <span style={{ fontSize: 12, color: 'var(--color-muted)' }}>{c.name}</span>
                </div>
                <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', fontWeight: 500 }}>${c.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Transactions */}
      <div style={{ padding: '0 32px' }}>
        <Card style={{ padding: 0 }}>
          <div style={{
            padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            borderBottom: '1px solid var(--color-border)',
          }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: 0 }}>Recent Transactions</h2>
            <button
              onClick={() => onNavigate('transactions')}
              style={{ background: 'none', border: 'none', color: 'var(--color-accent)', fontSize: 13, fontWeight: 500, cursor: 'pointer' }}
            >
              View all →
            </button>
          </div>
          {recentTx.map((tx, i) => (
            <div key={tx.id} style={{
              display: 'flex', alignItems: 'center', padding: '14px 24px',
              borderBottom: i < recentTx.length - 1 ? '1px solid var(--color-border)' : 'none',
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'var(--color-bg)',
                border: '1px solid var(--color-border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, marginRight: 12, flexShrink: 0,
              }}>{tx.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--color-text)' }}>{tx.merchant}</div>
                <div style={{ fontSize: 11, color: 'var(--color-muted)', marginTop: 1 }}>{tx.category} · {tx.date}</div>
              </div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 500,
                color: tx.amount > 0 ? 'var(--color-accent)' : 'var(--color-text)',
              }}>
                {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}
