import { useState } from 'react'
import { Card } from '../components/Card'

interface Goal {
  id: number
  name: string
  icon: string
  target: number
  saved: number
  deadline: string
  color: string
  type: 'savings' | 'investment' | 'debt'
}

const initialGoals: Goal[] = [
  { id: 1, name: 'Emergency Fund', icon: '🛡️', target: 20000, saved: 14610, deadline: 'Dec 2026', color: '#16a34a', type: 'savings' },
  { id: 2, name: 'Vacation — Japan', icon: '✈️', target: 5000, saved: 2400, deadline: 'Mar 2027', color: '#2563eb', type: 'savings' },
  { id: 3, name: 'New MacBook Pro', icon: '💻', target: 3500, saved: 1750, deadline: 'Oct 2026', color: '#7c3aed', type: 'savings' },
  { id: 4, name: 'Investment Portfolio', icon: '📈', target: 50000, saved: 32480, deadline: 'Dec 2027', color: '#d97706', type: 'investment' },
  { id: 5, name: 'Pay Off Student Loan', icon: '🎓', target: 12000, saved: 8200, deadline: 'Jun 2027', color: '#dc2626', type: 'debt' },
]

const typeColors: Record<string, string> = {
  savings: '#dcfce7',
  investment: '#fef3c7',
  debt: '#fee2e2',
}
const typeLabelColors: Record<string, string> = {
  savings: '#16a34a',
  investment: '#d97706',
  debt: '#dc2626',
}

export default function Goals() {
  const [goals] = useState<Goal[]>(initialGoals)
  const [selected, setSelected] = useState<number | null>(null)

  const totalSaved = goals.filter(g => g.type !== 'debt').reduce((s, g) => s + g.saved, 0)
  const totalTarget = goals.filter(g => g.type !== 'debt').reduce((s, g) => s + g.target, 0)

  return (
    <div style={{ padding: '28px 32px', paddingBottom: 40 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.4px' }}>
          Goals
        </h1>
        <p style={{ color: 'var(--color-muted)', fontSize: 13, margin: '4px 0 0' }}>
          Total saved toward goals:{' '}
          <strong style={{ fontFamily: 'var(--font-mono)', color: 'var(--color-text)' }}>
            ${totalSaved.toLocaleString()}
          </strong>
          {' '}of <strong style={{ fontFamily: 'var(--font-mono)', color: 'var(--color-text)' }}>${totalTarget.toLocaleString()}</strong>
        </p>
      </div>

      {/* Overall progress */}
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>Overall Goal Progress</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 600, color: 'var(--color-accent)' }}>
            {Math.round((totalSaved / totalTarget) * 100)}%
          </span>
        </div>
        <div style={{ background: 'var(--color-bg)', borderRadius: 99, height: 8, overflow: 'hidden' }}>
          <div style={{
            width: `${(totalSaved / totalTarget) * 100}%`, height: '100%',
            background: 'linear-gradient(90deg, #16a34a 0%, #4ade80 100%)',
            borderRadius: 99, transition: 'width 0.6s ease',
          }} />
        </div>
      </Card>

      {/* Goals grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {goals.map(goal => {
          const pct = Math.min((goal.saved / goal.target) * 100, 100)
          const remaining = goal.target - goal.saved
          const isSelected = selected === goal.id

          return (
            <div
              key={goal.id}
              onClick={() => setSelected(isSelected ? null : goal.id)}
              style={{
                background: 'var(--color-surface)',
                border: `2px solid ${isSelected ? goal.color : 'var(--color-border)'}`,
                borderRadius: 'var(--radius-lg)',
                padding: '20px 24px',
                cursor: 'pointer',
                transition: 'border-color 0.15s ease',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 22 }}>{goal.icon}</span>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-text)' }}>{goal.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--color-muted)', marginTop: 1 }}>Due {goal.deadline}</div>
                  </div>
                </div>
                <span style={{
                  fontSize: 10, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase',
                  padding: '3px 8px', borderRadius: 99,
                  background: typeColors[goal.type],
                  color: typeLabelColors[goal.type],
                }}>
                  {goal.type}
                </span>
              </div>

              {/* Progress bar */}
              <div style={{ marginBottom: 12 }}>
                <div style={{ background: 'var(--color-bg)', borderRadius: 99, height: 7, overflow: 'hidden', marginBottom: 8 }}>
                  <div style={{
                    width: `${pct}%`, height: '100%', borderRadius: 99,
                    background: goal.color, transition: 'width 0.5s ease',
                  }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>
                    ${goal.saved.toLocaleString()}
                  </span>
                  <span style={{ color: 'var(--color-muted)' }}>
                    {Math.round(pct)}% of ${goal.target.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Expanded detail */}
              {isSelected && (
                <div style={{
                  borderTop: '1px solid var(--color-border)', paddingTop: 12, marginTop: 4,
                  display: 'flex', flexDirection: 'column', gap: 6,
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                    <span style={{ color: 'var(--color-muted)' }}>Remaining</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>${remaining.toLocaleString()}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                    <span style={{ color: 'var(--color-muted)' }}>Monthly needed</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>
                      ${Math.ceil(remaining / 12).toLocaleString()}/mo
                    </span>
                  </div>
                  <button style={{
                    marginTop: 8, width: '100%',
                    background: goal.color, color: '#fff',
                    border: 'none', borderRadius: 6, padding: '7px 0',
                    fontSize: 12, fontWeight: 600, cursor: 'pointer',
                    fontFamily: 'var(--font-body)',
                  }}>
                    Add Funds
                  </button>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
