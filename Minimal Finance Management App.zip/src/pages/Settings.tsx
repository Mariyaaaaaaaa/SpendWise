import { useState } from 'react'
import { Card } from '../components/Card'

export default function Settings() {
  const [name, setName] = useState('Jamie Doe')
  const [email, setEmail] = useState('jamie@email.com')
  const [currency, setCurrency] = useState('USD')
  const [notifications, setNotifications] = useState({
    spending: true,
    goals: true,
    weekly: false,
    security: true,
  })
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('light')
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const toggle = (key: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <div style={{ padding: '28px 32px', paddingBottom: 40, maxWidth: 700 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.4px' }}>
          Settings
        </h1>
        <p style={{ color: 'var(--color-muted)', fontSize: 13, margin: '4px 0 0' }}>Profile, preferences, and configurations</p>
      </div>

      {/* Profile */}
      <Card style={{ marginBottom: 16 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 20px' }}>Profile</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            background: 'linear-gradient(135deg, #16a34a 0%, #15803d 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 20, fontWeight: 700, color: '#fff',
            flexShrink: 0,
          }}>JD</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600 }}>{name}</div>
            <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>Premium Plan · Member since Jan 2024</div>
          </div>
          <button style={{
            marginLeft: 'auto',
            background: 'var(--color-bg)', border: '1px solid var(--color-border)',
            borderRadius: 7, padding: '6px 14px', fontSize: 12, fontWeight: 500,
            cursor: 'pointer', fontFamily: 'var(--font-body)', color: 'var(--color-text)',
          }}>
            Change Photo
          </button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <span style={{ fontSize: 12, fontWeight: 500, color: 'var(--color-muted)' }}>Full Name</span>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              style={inputStyle}
            />
          </label>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <span style={{ fontSize: 12, fontWeight: 500, color: 'var(--color-muted)' }}>Email Address</span>
            <input
              value={email}
              onChange={e => setEmail(e.target.value)}
              style={inputStyle}
            />
          </label>
        </div>
      </Card>

      {/* Preferences */}
      <Card style={{ marginBottom: 16 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 20px' }}>Preferences</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Currency</div>
              <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>Display currency for all balances</div>
            </div>
            <select
              value={currency}
              onChange={e => setCurrency(e.target.value)}
              style={{ ...inputStyle, width: 120, padding: '7px 10px' }}
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="JPY">JPY (¥)</option>
            </select>
          </div>
          <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Appearance</div>
              <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>Choose your display theme</div>
            </div>
            <div style={{ display: 'flex', gap: 4, background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: 8, padding: 3 }}>
              {(['light', 'dark', 'system'] as const).map(t => (
                <button key={t} onClick={() => setTheme(t)} style={{
                  padding: '5px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
                  background: theme === t ? 'var(--color-text)' : 'transparent',
                  color: theme === t ? '#fff' : 'var(--color-muted)',
                  fontSize: 12, fontWeight: 500, fontFamily: 'var(--font-body)',
                  textTransform: 'capitalize',
                  transition: 'all 0.15s',
                }}>{t}</button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Notifications */}
      <Card style={{ marginBottom: 16 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 20px' }}>Notifications</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {[
            { key: 'spending' as const, label: 'Spending Alerts', desc: 'Notify when spending exceeds budget' },
            { key: 'goals' as const, label: 'Goal Milestones', desc: 'Celebrate when goals are reached' },
            { key: 'weekly' as const, label: 'Weekly Summary', desc: 'Email digest every Monday morning' },
            { key: 'security' as const, label: 'Security Alerts', desc: 'Unusual activity and login attempts' },
          ].map((item, i, arr) => (
            <div key={item.key} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '13px 0',
              borderBottom: i < arr.length - 1 ? '1px solid var(--color-border)' : 'none',
            }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{item.label}</div>
                <div style={{ fontSize: 12, color: 'var(--color-muted)' }}>{item.desc}</div>
              </div>
              <button
                onClick={() => toggle(item.key)}
                style={{
                  width: 40, height: 22, borderRadius: 99,
                  background: notifications[item.key] ? 'var(--color-accent)' : 'var(--color-border)',
                  border: 'none', cursor: 'pointer', position: 'relative', flexShrink: 0,
                  transition: 'background 0.2s',
                }}
              >
                <span style={{
                  position: 'absolute', top: 3, left: notifications[item.key] ? 21 : 3,
                  width: 16, height: 16, borderRadius: '50%', background: '#fff',
                  transition: 'left 0.2s',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
                }} />
              </button>
            </div>
          ))}
        </div>
      </Card>

      {/* Security */}
      <Card style={{ marginBottom: 24 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 16px' }}>Security</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button style={ghostBtnStyle}>Change Password</button>
          <button style={ghostBtnStyle}>Enable Two-Factor Authentication</button>
          <button style={{ ...ghostBtnStyle, color: 'var(--color-danger)', borderColor: '#fecaca' }}>
            Delete Account
          </button>
        </div>
      </Card>

      {/* Save button */}
      <button
        onClick={handleSave}
        style={{
          background: saved ? 'var(--color-accent)' : 'var(--color-text)',
          color: '#fff', border: 'none', borderRadius: 9,
          padding: '11px 28px', fontSize: 14, fontWeight: 600,
          cursor: 'pointer', fontFamily: 'var(--font-body)',
          transition: 'background 0.3s',
        }}
      >
        {saved ? '✓ Saved' : 'Save Changes'}
      </button>
    </div>
  )
}

const inputStyle: React.CSSProperties = {
  padding: '8px 12px',
  border: '1px solid var(--color-border)',
  borderRadius: 7,
  fontSize: 13,
  fontFamily: 'var(--font-body)',
  background: 'var(--color-surface)',
  color: 'var(--color-text)',
  outline: 'none',
}

const ghostBtnStyle: React.CSSProperties = {
  background: 'var(--color-bg)',
  border: '1px solid var(--color-border)',
  borderRadius: 7, padding: '9px 16px',
  fontSize: 13, fontWeight: 500,
  cursor: 'pointer', fontFamily: 'var(--font-body)',
  color: 'var(--color-text)', textAlign: 'left',
}
