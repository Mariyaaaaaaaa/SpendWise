import { useState } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from 'recharts'
import { Card } from '../components/Card'

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul']

const byMonth = [
  { month: 'Jan', Housing: 1400, Food: 520, Transport: 280, Entertainment: 180, Other: 420 },
  { month: 'Feb', Housing: 1400, Food: 490, Transport: 310, Entertainment: 220, Other: 380 },
  { month: 'Mar', Housing: 1400, Food: 610, Transport: 290, Entertainment: 195, Other: 450 },
  { month: 'Apr', Housing: 1400, Food: 540, Transport: 250, Entertainment: 160, Other: 400 },
  { month: 'May', Housing: 1400, Food: 580, Transport: 340, Entertainment: 210, Other: 480 },
  { month: 'Jun', Housing: 1400, Food: 620, Transport: 360, Entertainment: 250, Other: 510 },
  { month: 'Jul', Housing: 1400, Food: 580, Transport: 320, Entertainment: 210, Other: 590 },
]

const categories = [
  { name: 'Housing', color: '#111318', budget: 1400 },
  { name: 'Food', color: '#16a34a', budget: 600 },
  { name: 'Transport', color: '#2563eb', budget: 350 },
  { name: 'Entertainment', color: '#d97706', budget: 250 },
  { name: 'Other', color: '#9ca3af', budget: 500 },
]

const savingsTrend = months.map((m, i) => ({
  month: m,
  rate: [38, 40, 37, 42, 45, 44, 49][i],
}))

export default function Analytics() {
  const [range, setRange] = useState<'3m' | '6m' | '1y'>('6m')

  const sliceCount = range === '3m' ? 3 : range === '6m' ? 6 : 7
  const data = byMonth.slice(-sliceCount)
  const latest = byMonth[byMonth.length - 1]

  return (
    <div style={{ padding: '28px 32px', paddingBottom: 40 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, margin: 0, letterSpacing: '-0.4px' }}>
            Spending Analytics
          </h1>
          <p style={{ color: 'var(--color-muted)', fontSize: 13, margin: '4px 0 0' }}>Breakdown by category and trend</p>
        </div>
        <div style={{ display: 'flex', gap: 4, background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 8, padding: 4 }}>
          {(['3m', '6m', '1y'] as const).map(r => (
            <button key={r} onClick={() => setRange(r)} style={{
              padding: '5px 14px', borderRadius: 6, border: 'none', cursor: 'pointer',
              background: range === r ? 'var(--color-text)' : 'transparent',
              color: range === r ? '#fff' : 'var(--color-muted)',
              fontSize: 12, fontWeight: 500, fontFamily: 'var(--font-body)',
              transition: 'all 0.15s',
            }}>{r}</button>
          ))}
        </div>
      </div>

      {/* Stacked bar */}
      <Card style={{ marginBottom: 16 }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 4px' }}>
          Spending by Category
        </h2>
        <p style={{ fontSize: 12, color: 'var(--color-muted)', margin: '0 0 20px' }}>Monthly breakdown</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={data} barSize={28}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
            <Tooltip
              contentStyle={{ border: '1px solid var(--color-border)', borderRadius: 8, fontSize: 12 }}
              formatter={(v: number) => [`$${v}`, '']}
            />
            {categories.map(c => (
              <Bar key={c.name} dataKey={c.name} stackId="a" fill={c.color} radius={c.name === 'Other' ? [4, 4, 0, 0] : [0, 0, 0, 0]} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Budget vs actual */}
        <Card>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 16px' }}>
            Budget vs Actual — July
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {categories.map(c => {
              const actual = latest[c.name as keyof typeof latest] as number
              const pct = Math.min((actual / c.budget) * 100, 100)
              const over = actual > c.budget
              return (
                <div key={c.name}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                    <span style={{ fontSize: 12, fontWeight: 500 }}>{c.name}</span>
                    <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: over ? 'var(--color-danger)' : 'var(--color-muted)' }}>
                      ${actual} / ${c.budget}
                    </span>
                  </div>
                  <div style={{ background: 'var(--color-bg)', borderRadius: 99, height: 6, overflow: 'hidden' }}>
                    <div style={{
                      width: `${pct}%`, height: '100%', borderRadius: 99,
                      background: over ? 'var(--color-danger)' : c.color,
                      transition: 'width 0.4s ease',
                    }} />
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* Savings rate trend */}
        <Card>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, margin: '0 0 4px' }}>
            Savings Rate Trend
          </h2>
          <p style={{ fontSize: 12, color: 'var(--color-muted)', margin: '0 0 16px' }}>% of income saved each month</p>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={savingsTrend.slice(-sliceCount)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} domain={[30, 55]} />
              <Tooltip
                contentStyle={{ border: '1px solid var(--color-border)', borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => [`${v}%`, 'Savings Rate']}
              />
              <Line type="monotone" dataKey="rate" stroke="#16a34a" strokeWidth={2} dot={{ fill: '#16a34a', r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  )
}
